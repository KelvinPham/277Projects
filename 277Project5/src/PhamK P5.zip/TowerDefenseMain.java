import java.awt.Color;

import javax.swing.JFrame;

/**
 * the class simulates a tower defense game
 * @author Kelvin
 *
 */
public class TowerDefenseMain {
public static void main(String args[]){
	Frame f = new Frame();
	f.setTitle("TD");
	f.setBackground(Color.WHITE);
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	f.setVisible(true);
}
}
